package equipment;

/**
 *	Generated from IDL interface "EquipmentOrHolderIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface EquipmentOrHolderIterator_I
	extends EquipmentOrHolderIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
