package HW_controlPlane;

/**
 *	Generated from IDL interface "HW_SnppLinkIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface HW_SnppLinkIterator_I
	extends HW_SnppLinkIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
