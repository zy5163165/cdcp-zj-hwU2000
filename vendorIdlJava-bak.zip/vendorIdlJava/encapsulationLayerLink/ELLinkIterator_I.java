package encapsulationLayerLink;

/**
 *	Generated from IDL interface "ELLinkIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface ELLinkIterator_I
	extends ELLinkIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
