package HW_mstpInventory;

/**
 *	Generated from IDL definition of alias "HW_LinkAggregationGroupList_T"
 *	@author JacORB IDL compiler 
 */

public final class HW_LinkAggregationGroupList_THolder
	implements org.omg.CORBA.portable.Streamable
{
	public HW_mstpInventory.HW_LinkAggregationGroup_T[] value;

	public HW_LinkAggregationGroupList_THolder ()
	{
	}
	public HW_LinkAggregationGroupList_THolder (final HW_mstpInventory.HW_LinkAggregationGroup_T[] initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type ()
	{
		return HW_LinkAggregationGroupList_THelper.type ();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = HW_LinkAggregationGroupList_THelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream out)
	{
		HW_LinkAggregationGroupList_THelper.write (out,value);
	}
}
