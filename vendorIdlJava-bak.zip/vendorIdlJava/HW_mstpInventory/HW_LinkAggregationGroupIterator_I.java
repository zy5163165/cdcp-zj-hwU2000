package HW_mstpInventory;

/**
 *	Generated from IDL interface "HW_LinkAggregationGroupIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface HW_LinkAggregationGroupIterator_I
	extends HW_LinkAggregationGroupIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
