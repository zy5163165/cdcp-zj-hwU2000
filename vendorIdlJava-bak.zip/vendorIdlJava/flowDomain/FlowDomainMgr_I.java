package flowDomain;

/**
 *	Generated from IDL interface "FlowDomainMgr_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface FlowDomainMgr_I
	extends FlowDomainMgr_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, common.Common_I
{
}
