package circuitCutMgr;

/**
 *	Generated from IDL definition of struct "Position_T"
 *	@author JacORB IDL compiler 
 */

public final class Position_T
	implements org.omg.CORBA.portable.IDLEntity
{
	public Position_T(){}
	public int xPos;
	public int yPos;
	public Position_T(int xPos, int yPos)
	{
		this.xPos = xPos;
		this.yPos = yPos;
	}
}
