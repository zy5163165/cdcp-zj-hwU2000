package circuitCutMgr;

/**
 *	Generated from IDL definition of struct "ConnectivityNodePair_T"
 *	@author JacORB IDL compiler 
 */

public final class ConnectivityNodePair_T
	implements org.omg.CORBA.portable.IDLEntity
{
	public ConnectivityNodePair_T(){}
	public int aEnd;
	public int zEnd;
	public ConnectivityNodePair_T(int aEnd, int zEnd)
	{
		this.aEnd = aEnd;
		this.zEnd = zEnd;
	}
}
