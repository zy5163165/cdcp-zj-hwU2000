package circuitCutMgr;

/**
 *	Generated from IDL interface "ConnectivityNodePairIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface ConnectivityNodePairIterator_I
	extends ConnectivityNodePairIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
