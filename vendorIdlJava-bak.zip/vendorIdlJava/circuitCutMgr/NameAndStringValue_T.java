package circuitCutMgr;

/**
 *	Generated from IDL definition of struct "NameAndStringValue_T"
 *	@author JacORB IDL compiler 
 */

public final class NameAndStringValue_T
	implements org.omg.CORBA.portable.IDLEntity
{
	public NameAndStringValue_T(){}
	public java.lang.String name = "";
	public java.lang.String value = "";
	public NameAndStringValue_T(java.lang.String name, java.lang.String value)
	{
		this.name = name;
		this.value = value;
	}
}
